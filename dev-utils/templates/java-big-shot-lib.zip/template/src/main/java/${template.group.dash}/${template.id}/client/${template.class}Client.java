package ${template.group.dot}.${template.id}.client;

import net.typho.big_shot_lib.api.client.NeoClientInitializer;
import net.typho.big_shot_lib.api.event.NeoClientEventBus;

public class ${template.class}Client implements NeoClientInitializer {
    @Override
    public String getModId() {
        return "${template.id}";
    }

    @Override
    public void onInitializeClient(NeoClientEventBus bus) {
    }
}