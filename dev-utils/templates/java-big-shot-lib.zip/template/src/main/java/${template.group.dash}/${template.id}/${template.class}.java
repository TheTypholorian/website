package ${template.group.dot}.${template.id};

import net.typho.big_shot_lib.api.NeoCommonInitializer;
import net.typho.big_shot_lib.api.event.NeoEventBus;

public class ${template.class} implements NeoCommonInitializer {
    @Override
    public String getModId() {
        return "${template.id}";
    }

    @Override
    public void onInitialize(NeoEventBus bus) {
    }
}