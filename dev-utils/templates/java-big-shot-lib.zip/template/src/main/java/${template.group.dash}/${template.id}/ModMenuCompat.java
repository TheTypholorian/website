package ${template.group.dot}.${template.id};

import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;

public class ModMenuCompat implements ModMenuApi {
    @Override
    public ConfigScreenFactory<*> getModConfigScreenFactory() {
        return parent -> null;
    }
}