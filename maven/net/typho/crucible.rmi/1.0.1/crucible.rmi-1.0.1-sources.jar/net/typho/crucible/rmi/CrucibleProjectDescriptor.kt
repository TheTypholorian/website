package net.typho.crucible.rmi

import net.typho.crucible.ide.data.CrucibleIDEData

/**
 * IDE-relevant info about the project, which will later be combined to make a [CrucibleIDEData] instance.
 */
data class CrucibleProjectDescriptor(
    /**
     * The name, path, source sets, dependencies, and tasks of this project
     */
    @JvmField
    val module: CrucibleIDEData.Module,
    /**
     * Other crucible projects that this project depends on (absolute paths pointing to the folder containing the crucible wrapper jar)
     */
    @JvmField
    val dependencies: List<String>,
    /**
     * Script files to reload when this project is synced
     */
    @JvmField
    val scriptFiles: List<String>
)