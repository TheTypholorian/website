package net.typho.crucible.rmi

import java.rmi.Remote
import java.rmi.RemoteException

interface CrucibleRMI : Remote {
    @get:Throws(RemoteException::class)
    val version: String
    @get:Throws(RemoteException::class)
    val desc: CrucibleProjectDescriptor

    @Throws(RemoteException::class)
    fun getTask(id: String): TaskHandle<Unit>

    @Throws(RemoteException::class)
    fun <R> getTaskWithOutput(id: String): TaskHandle<R>

    interface TaskHandle<R> : () -> R, Remote {
        @get:Throws(RemoteException::class)
        val group: String
        @get:Throws(RemoteException::class)
        val description: String

        @Throws(RemoteException::class)
        fun getProperty(name: String): Any?

        @Throws(RemoteException::class)
        fun setProperty(name: String, value: Any?)
    }
}