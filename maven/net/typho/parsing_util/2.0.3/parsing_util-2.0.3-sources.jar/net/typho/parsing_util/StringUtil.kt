package net.typho.parsing_util

fun CharSequence.indexOf(
    other: CharSequence,
    startIndex: Int = 0,
    ignoreCase: Boolean = false
): Int {
    if (other.isEmpty()) {
        return startIndex.coerceIn(0, length)
    }

    for (index in startIndex.coerceAtLeast(0)..length - other.length) {
        if (regionMatches(index, other, 0, other.length, ignoreCase)) {
            return index
        }
    }

    return -1
}

operator fun CharSequence.get(range: IntRange) = StringView(this, range)
