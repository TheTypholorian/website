package net.typho.parsing_util

import net.typho.parsing_util.error.DataReadException

class StringView(
    @JvmField
    val text: CharSequence,
    @JvmField
	val range: IntRange
) : CharSequence {
    override val length = range.last - range.first

    override fun get(index: Int): Char {
        if (index !in indices) {
            throw IndexOutOfBoundsException(index.toString())
        }

        return this@StringView.text[range.first + index]
    }

    override fun subSequence(startIndex: Int, endIndex: Int): StringView {
        if (startIndex !in indices) {
            throw IndexOutOfBoundsException(startIndex.toString())
        }

        if (endIndex !in indices) {
            throw IndexOutOfBoundsException(endIndex.toString())
        }

        return StringView(this@StringView.text, (range.first + startIndex)..(range.first + endIndex))
    }

    @JvmOverloads
    fun offset(offset: Int, text: CharSequence = this@StringView.text) = StringView(text, (range.first + offset)..(range.last + offset))

    operator fun get(range: IntRange) = StringView(text, (this.range.first + range.first)..(this.range.first + range.last))

    override fun toString(): String {
        return text.substring(range.first, range.last)
    }

    fun rangeAsLineColumn() = DataReadException.lineAndColumn(text.toString(), range.first)
}