package net.typho.crucible.ide.data

import net.typho.data_util.SingleValueInput
import net.typho.data_util.SingleValueOutput
import net.typho.data_util.anno.FieldCodec
import net.typho.data_util.codec.Codec
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.ObjectInputStream
import java.io.ObjectOutputStream
import kotlin.script.experimental.api.ScriptCompilationConfiguration

data class CrucibleIDEData(
    @JvmField
    val projectName: String,
    @JvmField
    val sourceSets: List<SourceSet>,
    @JvmField
    val dependencies: List<Dependency>,
    @JvmField
    val tasks: List<Task>,
    @FieldCodec(owner = CrucibleIDEData::class, value = "SCRIPTS_CODEC")
    @JvmField
    val scripts: List<ScriptCompilationConfiguration>
) {
    companion object {
        @JvmField
        val SCRIPT_CODEC = object : Codec<ScriptCompilationConfiguration> {
            override fun read(input: SingleValueInput): ScriptCompilationConfiguration {
                val input = ObjectInputStream(ByteArrayInputStream(input.readString().toByteArray()))
                return input.readObject() as ScriptCompilationConfiguration
            }

            override fun write(
                output: SingleValueOutput,
                value: ScriptCompilationConfiguration
            ) {
                val bytes = ByteArrayOutputStream()
                ObjectOutputStream(bytes).writeObject(value)
                output.writeString(String(bytes.toByteArray()))
            }
        }
        @JvmField
        val SCRIPTS_CODEC = SCRIPT_CODEC.listOf()
        @JvmField
        val CODEC = Codec.reflect(CrucibleIDEData::class.java)
    }

    data class SourceSet(
        @JvmField
        val type: SourceSetType,
        @JvmField
        val generated: Boolean,
        @JvmField
        val path: String
    ) {
        companion object {
            @JvmField
            val CODEC = Codec.reflect(SourceSet::class.java)
        }
    }

    data class Task(
        @JvmField
        val id: String,
        @JvmField
        val group: String,
        @JvmField
        val description: String
    ) {
        companion object {
            @JvmField
            val CODEC = Codec.reflect(Task::class.java)
        }
    }
}
