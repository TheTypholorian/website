package net.typho.data_util.xml

import net.typho.parsing_util.error.DataReadException

open class XMLElement(
    name: String,
    attributes: MutableMap<String, String> = mutableMapOf(),
    @JvmField
    var children: MutableList<XMLNode> = mutableListOf()
) : XMLStubElement(name, attributes) {
    fun getChildren(name: String): List<XMLElement> {
        return children.filterIsInstance<XMLElement>().filter { it.name == name }
    }

    fun getChild(name: String): XMLElement {
        val results = getChildren(name)
        when (results.size) {
            0 -> throw DataReadException("Element ${this.name} does not have child with name $name")
            1 -> return results.single()
            else -> throw DataReadException("Element ${this.name} has multiple children with name $name")
        }
    }

    fun contentsAsString(prettyPrint: Boolean = false) = children.joinToString(separator = if (prettyPrint) "\n" else "") { it.toXMLString(prettyPrint) }

    override fun toXMLString(prettyPrint: Boolean) = buildString {
        append('<')
        append(name)

        for ((key, value) in attributes) {
            append(' ')
            append(key)
            append("=\"")
            append(XMLFormat.writeEntities(value))
            append('"')
        }

        if (children.isEmpty()) {
            if (name.startsWith('?')) {
                append("?>")
            } else {
                append("/>")
            }
        } else {
            append('>')

            if (children.size == 1 || !prettyPrint) {
                append(contentsAsString(prettyPrint))
            } else {
                append('\n')
                append(contentsAsString(prettyPrint).prependIndent("\t"))
                append('\n')
            }

            append("</")
            append(name)
            append('>')
        }
    }

    override fun toString() = buildString {
        append("XMLElement(name=").append(name)

        attributes.entries.forEach { (key, value) ->
            append(' ')
            append(key)
            append("=\"")
            append(value)
            append('"')
        }

        if (children.isNotEmpty()) {
            append(" children=${children}")
        }

        append(')')
    }
}