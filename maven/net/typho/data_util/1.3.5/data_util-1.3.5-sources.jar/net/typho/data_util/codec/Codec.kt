package net.typho.data_util.codec

import net.typho.data_util.DataReadException
import net.typho.data_util.DataReader
import net.typho.data_util.DataWriteException
import net.typho.data_util.DataWriter
import net.typho.data_util.SequentialInput
import net.typho.data_util.SequentialOutput
import net.typho.data_util.SingleValueInput
import net.typho.data_util.SingleValueOutput
import net.typho.data_util.anno.FieldCodec
import net.typho.data_util.anno.FieldDefault
import net.typho.data_util.anno.FieldRange
import net.typho.data_util.anno.InlineCodec
import org.jetbrains.annotations.Nullable
import java.lang.reflect.Field
import java.lang.reflect.Modifier
import java.lang.reflect.ParameterizedType
import java.util.function.Consumer
import java.util.function.Function
import java.util.function.Predicate
import kotlin.Double
import kotlin.Float
import kotlin.Int
import kotlin.Long
import kotlin.Short
import kotlin.jvm.java
import kotlin.reflect.jvm.kotlinProperty

interface Codec<T> : DataReader<T>, DataWriter<T> {
    companion object {
        private fun <T> simple(name: String, read: DataReader<T>, write: DataWriter<T>) = object : Codec<T> {
            override fun read(input: SingleValueInput): T {
                return read.read(input)
            }

            override fun write(output: SingleValueOutput, value: T) {
                write.write(output, value)
            }

            override fun toString(): String {
                return name
            }
        }

        @JvmField
        val NUMBER_CLASSES = listOf(
            Byte::class.java,
            Short::class.java,
            Int::class.java,
            Long::class.java,
            Float::class.java,
            Double::class.java
        )

        @JvmField
        val BOOL = simple("Boolean Codec", SingleValueInput::readBoolean, SingleValueOutput::writeBoolean)
        @JvmField
        val BYTE = simple("Byte Codec", SingleValueInput::readByte, SingleValueOutput::writeByte)
        @JvmField
        val SHORT = simple("Short Codec", SingleValueInput::readShort, SingleValueOutput::writeShort)
        @JvmField
        val INT = simple("Int Codec", SingleValueInput::readInt, SingleValueOutput::writeInt)
        @JvmField
        val VAR_INT = simple("Var Int Codec", SingleValueInput::readVarInt, SingleValueOutput::writeVarInt)
        @JvmField
        val LONG = simple("Long Codec", SingleValueInput::readLong, SingleValueOutput::writeLong)
        @JvmField
        val FLOAT = simple("Float Codec", SingleValueInput::readFloat, SingleValueOutput::writeFloat)
        @JvmField
        val DOUBLE = simple("Double Codec", SingleValueInput::readDouble, SingleValueOutput::writeDouble)
        @JvmField
        val STRING = simple("String Codec", SingleValueInput::readString, SingleValueOutput::writeString)

        @JvmOverloads
        @JvmStatic
        fun <E : Enum<E>> enumCodec(cls: Class<E>, caseSensitive: Boolean = false): Codec<E> {
            return object : Codec<E> {
                override fun read(input: SingleValueInput): E {
                    try {
                        return input.readEnum(cls, caseSensitive)
                    } catch (e: RuntimeException) {
                        throw DataReadException("Error while reading enum entry of class $cls", e, true, false)
                    }
                }

                override fun write(output: SingleValueOutput, value: E) {
                    try {
                        output.writeEnum(value)
                    } catch (e: RuntimeException) {
                        throw DataWriteException("Error while writing enum entry of class $cls", e, true, false)
                    }
                }

                override fun toString(): String {
                    return "Enum Codec for $cls"
                }
            }
        }

        @JvmStatic
        fun <V> unboundedMap(valueCodec: Codec<V>): Codec<Map<String, V>> {
            return object : Codec<Map<String, V>> {
                override fun read(input: SingleValueInput): Map<String, V> {
                    val map = mutableMapOf<String, V>()
                    input.readDynamicMap().forEach { (key, value) -> map[key] = valueCodec.read(value) }
                    return map
                }

                override fun write(
                    output: SingleValueOutput,
                    value: Map<String, V>
                ) {
                    output.writeDynamicMap(value.map { (key, value) -> key to Consumer { valueCodec.write(it, value) } })
                }
            }
        }

        @Suppress("UNCHECKED_CAST")
        @JvmOverloads
        @JvmStatic
        fun <T> getPrimitiveCodec(cls: Class<T>, isVarInt: Boolean = false): Codec<T>? {
            return when (cls) {
                Boolean::class.java, Boolean::class.javaObjectType -> BOOL as Codec<T>
                Byte::class.java, Byte::class.javaObjectType -> BYTE as Codec<T>
                Short::class.java, Short::class.javaObjectType -> SHORT as Codec<T>
                Int::class.java, Int::class.javaObjectType -> (if (isVarInt) VAR_INT else INT) as Codec<T>
                Long::class.java, Long::class.javaObjectType -> LONG as Codec<T>
                Float::class.java, Float::class.javaObjectType -> FLOAT as Codec<T>
                Double::class.java, Double::class.javaObjectType -> DOUBLE as Codec<T>
                String::class.java -> STRING as Codec<T>
                else -> if (cls.isEnum) enumCodec(cls as Class<out Enum<*>>) as Codec<T> else null
            }
        }

        @Suppress("UNCHECKED_CAST")
        @JvmStatic
        fun getClassCodec(owner: Class<*>, type: Class<*>): Codec<*>? {
            var codec = getPrimitiveCodec(type)

            if (codec == null) {
                try {
                    val codecField = type.getDeclaredField("CODEC")
                    codecField.isAccessible = true
                    codec = codecField.get(null) as Codec<*>
                } catch (_: NoSuchFieldException) {
                }
            }

            return codec
        }

        @Suppress("UNCHECKED_CAST")
        @JvmStatic
        fun getFieldCodec(owner: Class<*>, field: Field): Codec<*> {
            var codec: Codec<*>? = null

            for (anno in field.annotations) {
                if (anno is FieldCodec) {
                    try {
                        var target = anno.owner.java

                        if (target == Any::class.java) {
                            target = field.type
                        }

                        val codecField = target.getDeclaredField(anno.value)

                        if (!Modifier.isStatic(codecField.modifiers)) {
                            throw IllegalStateException("Field ${owner.name} ${field.type.name} ${field.name} has @FieldCodec pointing to a non-static codec field")
                        }

                        if (!Codec::class.java.isAssignableFrom(codecField.type)) {
                            throw IllegalStateException("Field ${owner.name} ${field.type.name} ${field.name} has @FieldCodec pointing to a field that isn't a codec")
                        }

                        codecField.isAccessible = true

                        codec = codecField.get(null) as Codec<*>
                        break
                    } catch (_: NoSuchFieldException) {
                        throw IllegalStateException("Field ${owner.name} ${field.type.name} ${field.name} has @FieldCodec pointing to a nonexistent field")
                    }
                }
            }

            codec = codec ?: getClassCodec(owner, field.type)

            if (codec == null) {
                if (List::class.java.isAssignableFrom(field.type) && field.type != List::class.java) {
                    throw IllegalStateException("Field ${owner.name} ${field.type.name} ${field.name} extends List but doesn't provide a codec, automatic list codecs are only for raw List types.")
                }

                var type = field.genericType as ParameterizedType
                var depth = 0

                while (type.rawType == List::class.java) {
                    depth++

                    val arg = type.actualTypeArguments[0]

                    if (arg is ParameterizedType) {
                        type = arg
                    } else if (arg is Class<*>) {
                        codec = getClassCodec(owner, arg) ?: throw IllegalStateException("Field ${owner.name} ${field.type.name} ${field.name} is a List and its deep type has no automatic codec")
                        break
                    }
                }

                if (depth > 0 && codec != null) {
                    repeat(depth) {
                        codec = codec!!.listOf()
                    }
                }
            }

            var codec1 = codec ?: throw IllegalStateException("Field ${owner.name} ${field.type.name} ${field.name} is missing a codec")

            for (anno in field.annotations) {
                if (anno is FieldRange) {
                    if (!(Number::class.java.isAssignableFrom(field.type) || NUMBER_CLASSES.contains(field.type))) {
                        throw IllegalStateException("Field ${owner.name} ${field.type.name} ${field.name} has @FieldRange but isn't a number field")
                    }

                    codec1 = codec1.withCondition(
                        {
                            val n = (it as Number).toDouble()
                            n >= anno.min && n <= anno.max
                        },
                        { "$it must be between ${anno.min} and ${anno.max}" },
                        "range [${anno.min}, ${anno.max}]"
                    )
                    break
                }
            }

            val default = field.annotations.filterIsInstance<FieldDefault>().firstOrNull()?.let { anno ->
                var target = anno.owner.java

                if (target == Any::class.java) {
                    when (field.type) {
                        Boolean::class.java, Boolean::class.javaObjectType -> return@let anno.value.toBoolean()
                        Byte::class.java, Byte::class.javaObjectType -> return@let anno.value.toByte()
                        Short::class.java, Short::class.javaObjectType -> return@let anno.value.toShort()
                        Int::class.java, Int::class.javaObjectType -> return@let anno.value.toInt()
                        Long::class.java, Long::class.javaObjectType -> return@let anno.value.toLong()
                        Float::class.java, Float::class.javaObjectType -> return@let anno.value.toFloat()
                        Double::class.java, Double::class.javaObjectType -> return@let anno.value.toDouble()
                        String::class.java -> return@let anno.value
                        else -> target = field.type
                    }
                }

                try {
                    val defaultField = target.getDeclaredField(anno.value)

                    if (!Modifier.isStatic(defaultField.modifiers)) {
                        throw IllegalStateException("Field ${target.name} ${field.type.name} ${field.name} has @FieldDefault pointing to a non-static field")
                    }

                    if (!field.type.isAssignableFrom(defaultField.type)) {
                        throw IllegalStateException("Field ${target.name} ${field.type.name} ${field.name} has @FieldDefault pointing to a field that isn't the same type as the field")
                    }

                    defaultField.isAccessible = true

                    return@let defaultField.get(null)
                } catch (e: NoSuchFieldException) {
                    throw IllegalStateException("Field ${target.name} ${field.type.name} ${field.name} has @FieldDefault pointing to a nonexistent field")
                }
            }

            fun <T> generics(codec: Codec<T>): Codec<*> {
                return if (default != null || field.isAnnotationPresent(Nullable::class.java) || field.kotlinProperty?.returnType?.isMarkedNullable == true) {
                    if (default == null) codec.optional() else codec.optional(default as T)
                } else {
                    codec
                }
            }

            return generics(codec1)
        }

        @JvmStatic
        fun <T> either(primary: Codec<T>, options: List<DataReader<T>>): Codec<T> {
            if (options.isEmpty()) {
                throw IllegalArgumentException("Must specify at least one option")
            }

            val all = mutableListOf<DataReader<T>>(primary)
            all.addAll(options)

            return object : Codec<T> {
                override fun read(input: SingleValueInput): T {
                    return input.readEither(all)
                }

                override fun write(output: SingleValueOutput, value: T) {
                    primary.write(output, value)
                }

                override fun toString(): String {
                    return "Either codec with primary $primary and options [${options.joinToString(separator = "\n", prefix = "\n").replace("\n", "\n\t")}\n]"
                }
            }
        }

        /**
         * @param reverseInheritanceOrder defines where superclass fields are in the constructor, True = at the end and False = at the start (defaults to false because it's the IntelliJ default)
         */
        @Suppress("UNCHECKED_CAST")
        @JvmStatic
        fun <T> reflect(cls: Class<T>, reverseInheritanceOrder: Boolean = false): Codec<T> {
            data class Entry(
                @JvmField
                val field: Field,
                @JvmField
                val codec: Codec<*>
            )

            val fields = mutableListOf<Field>()
            var temp: Class<*>? = cls

            while (temp != null) {
                val clsFields = temp.declaredFields.filter { !Modifier.isStatic(it.modifiers) && !Modifier.isTransient(it.modifiers) }

                if (reverseInheritanceOrder) {
                    fields.addAll(clsFields)
                } else {
                    fields.addAll(0, clsFields)
                }

                temp = temp.superclass
            }

            fields.forEach { it.isAccessible = true }

            val types = fields.map { it.type }.toTypedArray()
            val constructor = cls.constructors.firstOrNull {
                it.parameterTypes.contentEquals(types)
            } ?: throw IllegalArgumentException("$cls is missing a constructor matching ${fields.map { "${it.type} ${it.name}" }}")

            val entries = fields.map { field -> Entry(field, getFieldCodec(cls, field)) }

            val codec = object : MapCodec<T> {
                override val keys = entries.map { it.field.name }

                override fun read(input: SequentialInput): T {
                    val args = entries.map {
                        try {
                            it.codec.read(input.readNextEntry())
                        } catch (e: RuntimeException) {
                            throw DataReadException("Error while reading map entry ${it.field.name}", e, true, false)
                        }
                    }
                    return constructor.newInstance(*args.toTypedArray()) as T
                }

                fun <V> write(field: Field, codec: Codec<V>, value: T, output: SequentialOutput) {
                    try {
                        codec.write(output.writeNextEntry(), field.get(value) as V)
                    } catch (e: RuntimeException) {
                        throw DataWriteException("Error while writing map entry ${field.name}", e, true, false)
                    }
                }

                override fun write(output: SequentialOutput, value: T) {
                    for (entry in entries) {
                        write(entry.field, entry.codec, value, output)
                    }
                }

                override fun toString(): String {
                    return "Reflected MapCodec of $cls, fields: {${entries.joinToString(separator = "\n", prefix = "\n", transform = { "'${it.field.name}' with codec ${it.codec}" }).replace("\n", "\n\t")}\n}"
                }
            }

            return if (cls.isAnnotationPresent(InlineCodec::class.java)) {
                val inline = cls.getAnnotation(InlineCodec::class.java)
                val candidates = entries.withIndex().filter { it.value.codec !is OptionalCodec }

                if (candidates.size != 1) {
                    throw IllegalArgumentException("$cls has @InlineCodec but has ${candidates.size} non-optional fields, must be exactly one.")
                }

                val primary = candidates.first()
                val reader = object : DataReader<T> {
                    override fun read(input: SingleValueInput): T {
                        val args = entries.mapIndexed { index, entry -> if (index == primary.index) {
                            try {
                                primary.value.codec.read(input)
                            } catch (e: RuntimeException) {
                                throw DataReadException("Error while reading inlined map entry ${entry.field.name}", e, true, false)
                            }
                        } else (entry.codec as OptionalCodec).default }
                        return constructor.newInstance(*args.toTypedArray()) as T
                    }

                    override fun toString(): String {
                        return "Reflected inline reader of $cls"
                    }
                }

                if (inline.writeInlined) {
                    either(object : MapCodec<T> {
                        override val keys = entries.map { it.field.name }

                        override fun read(input: SequentialInput): T {
                            val args = entries.map {
                                try {
                                    it.codec.read(input.readNextEntry())
                                } catch (e: RuntimeException) {
                                    throw DataReadException("Error while reading map entry ${it.field.name}", e, true, false)
                                }
                            }
                            return constructor.newInstance(*args.toTypedArray()) as T
                        }

                        fun <V> writeInline(field: Field, codec: Codec<V>, value: T, output: SingleValueOutput) {
                            try {
                                codec.write(output, field.get(value) as V)
                            } catch (e: RuntimeException) {
                                throw DataWriteException("Error while writing map entry ${field.name}", e, true, false)
                            }
                        }

                        fun <V> writeAlreadyGotten(field: Field, codec: Codec<V>, value: Any?, output: SequentialOutput) {
                            try {
                                codec.write(output.writeNextEntry(), value as V)
                            } catch (e: RuntimeException) {
                                throw DataWriteException("Error while writing map entry ${field.name}", e, true, false)
                            }
                        }

                        fun <V> write(field: Field, codec: Codec<V>, value: T, output: SequentialOutput) {
                            try {
                                codec.write(output.writeNextEntry(), field.get(value) as V)
                            } catch (e: RuntimeException) {
                                throw DataWriteException("Error while writing map entry ${field.name}", e, true, false)
                            }
                        }

                        override fun write(output: SequentialOutput, value: T) {
                            for (entry in entries) {
                                write(entry.field, entry.codec, value, output)
                            }
                        }

                        override fun write(output: SingleValueOutput, value: T) {
                            val values = entries.map { entry -> entry.field.get(value) }
                            var canInline = true

                            values.forEachIndexed { index, value ->
                                val codec = entries[index].codec

                                if (codec is OptionalCodec) {
                                    if (codec.default != value) {
                                        canInline = false
                                    }
                                }
                            }

                            if (canInline) {
                                writeInline(primary.value.field, primary.value.codec, value, output)
                            } else {
                                val map = output.writeStaticMap(keys)

                                entries.forEachIndexed { index, entry ->
                                    writeAlreadyGotten(entry.field, entry.codec, values[index], map)
                                }
                            }
                        }

                        override fun toString(): String {
                            return "Reflected MapCodec of $cls, fields: {${entries.joinToString(separator = "\n", prefix = "\n", transform = { "'${it.field.name}' with codec ${it.codec}" }).replace("\n", "\n\t")}\n}"
                        }
                    }, listOf(reader))
                } else {
                    either(codec, listOf(reader))
                }
            } else codec
        }
    }

    fun withCondition(condition: Predicate<T>, error: Function<T, String>, name: String): Codec<T> {
        val parent = this
        return object : Codec<T> {
            override fun read(input: SingleValueInput): T {
                val value = parent.read(input)

                if (!condition.test(value)) {
                    throw DataReadException(error.apply(value))
                }

                return value
            }

            override fun write(output: SingleValueOutput, value: T) {
                if (!condition.test(value)) {
                    throw DataWriteException(error.apply(value))
                }

                parent.write(output, value)
            }

            override fun toString(): String {
                return "$parent, with condition $name"
            }
        }
    }

    fun optional(): OptionalCodec<T?> {
        val parent = this
        return object : OptionalCodec<T?> {
            override val default: T?
                get() = null

            override fun read(input: SingleValueInput): T? {
                return input.readOptional(parent)
            }

            override fun write(output: SingleValueOutput, value: T?) {
                output.writeOptional(value, parent)
            }

            override fun toString(): String {
                return "$parent, optional"
            }
        }
    }

    fun optional(default: T): OptionalCodec<T> {
        val parent = this
        return object : OptionalCodec<T> {
            override val default: T
                get() = default

            override fun read(input: SingleValueInput): T {
                return input.readOptional(parent) ?: default
            }

            override fun write(output: SingleValueOutput, value: T) {
                output.writeOptional(value, parent)
            }

            override fun toString(): String {
                return "$parent, optional with default $default"
            }
        }
    }

    fun listOf(): Codec<List<T>> {
        val parent = this
        return object : Codec<List<T>> {
            override fun read(input: SingleValueInput): List<T> {
                return input.readList().toList(parent::read)
            }

            override fun write(output: SingleValueOutput, value: List<T>) {
                val list = output.writeList(value.size)
                value.forEach { parent.write(list.writeNextEntry(), it) }
            }

            override fun toString(): String {
                return "$parent as list"
            }
        }
    }

    fun <N> map(
        read: Function<T, N>,
        write: Function<N, T>
    ): Codec<N> {
        val parent = this
        return object : Codec<N> {
            override fun read(input: SingleValueInput): N {
                return read.apply(parent.read(input))
            }

            override fun write(output: SingleValueOutput, value: N) {
                parent.write(output, write.apply(value))
            }

            override fun toString(): String {
                return "$parent mapped with read $read and write $write"
            }
        }
    }

    fun <N> map(
        cls: Class<N>,
        read: Function<T, N>,
        write: Function<N, T>
    ): Codec<N> {
        val parent = this
        return object : Codec<N> {
            override fun read(input: SingleValueInput): N {
                return read.apply(parent.read(input))
            }

            override fun write(output: SingleValueOutput, value: N) {
                parent.write(output, write.apply(value))
            }

            override fun toString(): String {
                return "$parent mapped to ${cls.name}"
            }
        }
    }
}